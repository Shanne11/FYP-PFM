import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:pocketiq/core/database/app_database.dart';
import 'package:pocketiq/ml/learning/local_calibration_model.dart';

class OptionalLearningResult {
  const OptionalLearningResult({
    required this.syncId,
    required this.sampleCount,
    required this.usefulNoteCount,
    required this.averageHeuristic,
    required this.lossBefore,
    required this.lossAfter,
    required this.updateNorm,
  });
  final String syncId;
  final int sampleCount;
  final int usefulNoteCount;
  final double averageHeuristic;
  final double lossBefore;
  final double lossAfter;
  final double updateNorm;
}

class OptionalLearningService {
  OptionalLearningService(
    this.database,
    this.store, {
    LocalCalibrationTrainer? trainer,
  }) : trainer = trainer ?? const LocalCalibrationTrainer();
  final AppDatabase database;
  final ProbabilityCalibrationStore store;
  final LocalCalibrationTrainer trainer;

  /// Remote calibration exchange is deliberately disabled until PocketIQ's
  /// 210-parameter deployment contract has a verified compatible server.
  static const bool remoteSyncEnabled = false;

  static const deploymentCategories = <String>[
    'Bills & Utilities',
    'Education',
    'Entertainment',
    'Fees & Charges',
    'Food & Dining',
    'Health & Medical',
    'Housing',
    'Insurance',
    'Other Income',
    'Personal Care',
    'Shopping',
    'Transfers',
    'Transportation',
    'Travel',
  ];

  Future<OptionalLearningResult> trainAndPrepare() async {
    final transactions = await database.select(database.transactionRows).get();
    final logs = await database.select(database.auditLogRows).get();
    const eligibleActions = <String>{
      'category_correction',
      'smart_note_confirmation',
      'smart_note_category_correction',
    };
    final eligibleIds = logs
        .where((log) => eligibleActions.contains(log.action))
        .map((log) => log.entityId)
        .toSet();
    final examples = <CalibrationExample>[];
    final usedIds = <String>{};
    for (final transaction in transactions) {
      if (!eligibleIds.contains(transaction.id)) continue;
      final encoded = transaction.predictionProbabilities;
      if (encoded == null) continue;
      try {
        final probabilities = List<num>.from(
          jsonDecode(encoded) as List,
        ).map((value) => value.toDouble()).toList(growable: false);
        final target = deploymentCategories.indexOf(
          _deploymentCategory(
            transaction.finalCategory,
            transaction.transactionType,
          ),
        );
        if (probabilities.length == calibrationClassCount && target >= 0) {
          examples.add(
            CalibrationExample(probabilities: probabilities, target: target),
          );
          usedIds.add(transaction.id);
        }
      } on Object {
        // Legacy or malformed probability vectors are ineligible, not fatal.
      }
    }
    if (examples.length < 2) {
      throw StateError(
        'At least two confirmed or corrected transactions with stored ONNX probabilities are required.',
      );
    }
    final notes = await database.select(database.smartNoteRows).get();
    final validNotes = notes
        .where((note) => usedIds.contains(note.transactionId))
        .toList();
    final averageHeuristic = validNotes.isEmpty
        ? 0.0
        // rawUtility is the legacy Drift field for the clarification heuristic.
        : validNotes
                  .map((note) => note.rawUtility.clamp(0.0, 1.0))
                  .fold<double>(0, (sum, value) => sum + value) /
              validNotes.length;
    final initial = await store.load();
    final update = trainer.train(initial, examples);
    await store.save(update.state);
    // Local-only by design: do not serialize an update payload or create a
    // pending synchronization record while the remote contract is disabled.
    final id = 'local-calibration-v${update.state.version}';
    return OptionalLearningResult(
      syncId: id,
      sampleCount: update.sampleCount,
      usefulNoteCount: validNotes.length,
      averageHeuristic: averageHeuristic,
      lossBefore: update.lossBefore,
      lossAfter: update.lossAfter,
      updateNorm: update.updateNorm,
    );
  }

  Future<int> syncPending(
    String serverUrl, {
    required String researchToken,
  }) async {
    throw StateError(
      'Remote calibration upload is disabled. PocketIQ calibration remains local to this device.',
    );
  }

  Future<int> deletePendingUpdates() async {
    final pending = await (database.select(
      database.federatedSyncRows,
    )..where((row) => row.status.equals('pending'))).get();
    for (final sync in pending) {
      final file = await _payloadFile(sync.id);
      if (await file.exists()) {
        await file.delete();
      }
    }
    return database.deletePendingFederatedUpdates();
  }

  Future<File> _payloadFile(String id) async {
    final directory = await getApplicationSupportDirectory();
    return File(
      '${directory.path}${Platform.pathSeparator}pending_learning_$id.json',
    );
  }

  static String _deploymentCategory(String category, String type) {
    final value = category.toLowerCase();
    if (type.toLowerCase() == 'income') {
      if (value.contains('transfer') || value.contains('loan')) {
        return 'Transfers';
      }
      return 'Other Income';
    }
    if (value.contains('food') ||
        value.contains('beverage') ||
        value.contains('snack')) {
      return 'Food & Dining';
    }
    if (value.contains('education')) return 'Education';
    if (value.contains('entertainment')) return 'Entertainment';
    if (value.contains('fee') ||
        value.contains('tax') ||
        value.contains('debt') ||
        value.contains('loan')) {
      return 'Fees & Charges';
    }
    if (value.contains('health') ||
        value.contains('medical') ||
        value.contains('care')) {
      return value.contains('personal') ? 'Personal Care' : 'Health & Medical';
    }
    if (value.contains('housing') || value.contains('rent')) return 'Housing';
    if (value.contains('bill') || value.contains('utilit')) {
      return 'Bills & Utilities';
    }
    if (value.contains('insurance')) return 'Insurance';
    if (value.contains('transport') || value.contains('parking')) {
      return 'Transportation';
    }
    if (value.contains('travel')) return 'Travel';
    if (value.contains('shop') || value.contains('family')) return 'Shopping';
    if (value.contains('transfer') || value.contains('saving')) {
      return 'Transfers';
    }
    // The deployment category space has no expense-side Other label. Local
    // fallback categories are therefore not calibration-training targets.
    return '';
  }
}
