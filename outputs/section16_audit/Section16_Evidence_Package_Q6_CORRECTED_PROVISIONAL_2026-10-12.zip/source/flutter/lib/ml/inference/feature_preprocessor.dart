import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/services.dart';
import 'package:pocketiq/ml/inference/transaction_categoriser.dart';

class ModelFeatureSchema {
  ModelFeatureSchema._(this._json);

  final Map<String, dynamic> _json;

  static Future<ModelFeatureSchema> load({
    String asset = 'assets/models/feature_schema.json',
  }) async => ModelFeatureSchema._(
    jsonDecode(await rootBundle.loadString(asset)) as Map<String, dynamic>,
  );

  bool get isDeploymentText =>
      _json['model_family'] == 'pocketiq_deployment_text';
  String get categorySpace => _json['category_space'] as String? ?? 'research';
  List<String> get categories =>
      List<String>.from(_json['category_order'] as List);
  List<String> get categoricalColumns =>
      List<String>.from(_json['categorical_columns'] as List? ?? const []);
  List<String> get numericColumns =>
      List<String>.from(_json['numeric_columns'] as List? ?? const []);
  List<String> get featureOrder =>
      List<String>.from(_json['feature_order'] as List);
  Map<String, dynamic> get tensorContract =>
      Map<String, dynamic>.from(_json['tensor_contract'] as Map);
  Map<String, dynamic> get _textBlock => Map<String, dynamic>.from(
    (isDeploymentText ? _json['text'] : _json['note']) as Map,
  );
  List<double> get scalerMean => List<num>.from(
    _json['numeric_scaler_mean'] as List? ?? const [],
  ).map((value) => value.toDouble()).toList(growable: false);
  List<double> get scalerScale => List<num>.from(
    _json['numeric_scaler_scale'] as List? ?? const [],
  ).map((value) => value.toDouble()).toList(growable: false);
  Map<String, List<String>> get categoricalValues => (Map<String, dynamic>.from(
    _json['categorical_values'] as Map? ?? const {},
  )).map((key, value) => MapEntry(key, List<String>.from(value as List)));
  Map<String, int> get vocabulary => (Map<String, dynamic>.from(
    _textBlock['vocabulary'] as Map,
  )).map((key, value) => MapEntry(key, value as int));
  List<double> get idf => List<num>.from(
    _textBlock['idf'] as List,
  ).map((value) => value.toDouble()).toList(growable: false);
  Set<String> get stopWords =>
      Set<String>.from(_textBlock['english_stop_words'] as List? ?? const []);
  List<int> get ngramRange =>
      List<int>.from(_textBlock['ngram_range'] as List? ?? const [1, 1]);
  bool get sublinearTf => _textBlock['sublinear_tf'] as bool? ?? false;
  int get totalFeatures =>
      (Map<String, dynamic>.from(_json['feature_dimensions'] as Map))['total']
          as int;
  double get confidenceThreshold {
    final policy = _json['inference_policy'];
    if (policy is! Map) return .75;
    return (policy['confidence_threshold'] as num?)?.toDouble() ?? .75;
  }
}

class FrozenFeaturePreprocessor {
  const FrozenFeaturePreprocessor(this.schema);

  final ModelFeatureSchema schema;

  List<double> transform(
    TransactionInput input, {
    String? smartNote,
    bool useNote = false,
  }) {
    if (schema.isDeploymentText) {
      final output = _tfidf(
        _deploymentText(
          input,
          smartNote: useNote ? smartNote?.trim() ?? '' : '',
        ),
      );
      _validateLength(output);
      return List<double>.unmodifiable(output);
    }

    final categorical = <String, String>{
      'transaction_type': input.transactionType,
      'payment_mode': input.paymentMode,
      'location': input.location,
    };
    final output = <double>[];
    final categoryValues = schema.categoricalValues;
    for (final column in schema.categoricalColumns) {
      final selected = categorical[column] ?? 'Unknown';
      output.addAll(
        categoryValues[column]!.map((value) => value == selected ? 1.0 : 0.0),
      );
    }

    final numeric = <double>[
      input.amountMinor / 100,
      input.date.year.toDouble(),
      input.date.month.toDouble(),
      input.date.day.toDouble(),
      (input.date.weekday - 1).toDouble(),
    ];
    for (var index = 0; index < numeric.length; index++) {
      output.add(
        (numeric[index] - schema.scalerMean[index]) / schema.scalerScale[index],
      );
    }

    final noteEvidence = analyseNote(input, smartNote ?? '', eligible: useNote);
    output.addAll(
      noteEvidence.noteVector.map((value) => value * noteEvidence.gate),
    );
    _validateLength(output);
    return List<double>.unmodifiable(output);
  }

  NoteFeatureEvidence analyseNote(
    TransactionInput input,
    String note, {
    bool eligible = true,
  }) {
    final trimmedNote = note.trim();
    final noteVector = _tfidf(trimmedNote);
    final anchorVector = _tfidf(
      schema.isDeploymentText
          ? _deploymentText(input)
          : '${input.transactionType} ${input.paymentMode} ${input.location}',
    );
    final recognisedTokenCount = _terms(
      trimmedNote,
    ).where(schema.vocabulary.containsKey).length;
    final noteNorm = _norm(noteVector);
    final anchorNorm = _norm(anchorVector);
    final specificity = noteNorm == 0 || anchorNorm == 0
        ? 0.0
        : (1 - _dot(noteVector, anchorVector) / (noteNorm * anchorNorm)).clamp(
            0.0,
            1.0,
          );
    final noteAvailable = eligible && trimmedNote.isNotEmpty;
    final gate = noteAvailable && recognisedTokenCount > 0
        ? schema.isDeploymentText
              ? 1.0
              : 0.5 + 0.5 * specificity
        : 0.0;
    final tokenCount = RegExp(r'[A-Za-z0-9]+').allMatches(trimmedNote).length;
    return NoteFeatureEvidence(
      noteVector: List<double>.unmodifiable(noteVector),
      anchorVector: List<double>.unmodifiable(anchorVector),
      specificity: specificity,
      gate: gate,
      tokenCount: tokenCount,
      recognisedTokenCount: recognisedTokenCount,
      noteAvailable: noteAvailable,
    );
  }

  String _deploymentText(TransactionInput input, {String smartNote = ''}) {
    final direction = input.transactionType.toLowerCase() == 'income'
        ? 'credit'
        : 'debit';
    return <String>[
      direction,
      input.merchant.trim(),
      input.description.trim(),
      smartNote.trim(),
    ].where((value) => value.isNotEmpty).join(' ');
  }

  List<String> _terms(String text) {
    final tokens = RegExp(r'\b\w\w+\b')
        .allMatches(text.toLowerCase())
        .map((match) => match.group(0)!)
        .where((token) => !schema.stopWords.contains(token))
        .toList(growable: false);
    final range = schema.ngramRange;
    final terms = <String>[];
    for (var size = range.first; size <= range.last; size++) {
      for (var start = 0; start + size <= tokens.length; start++) {
        terms.add(tokens.sublist(start, start + size).join(' '));
      }
    }
    return terms;
  }

  List<double> _tfidf(String text) {
    final vocabulary = schema.vocabulary;
    final counts = List<double>.filled(vocabulary.length, 0);
    for (final term in _terms(text)) {
      final index = vocabulary[term];
      if (index != null) counts[index]++;
    }
    final weighted = List<double>.generate(counts.length, (index) {
      final count = counts[index];
      final termFrequency = schema.sublinearTf && count > 0
          ? 1 + math.log(count)
          : count;
      return termFrequency * schema.idf[index];
    }, growable: false);
    final norm = _norm(weighted);
    return norm == 0
        ? weighted
        : weighted.map((value) => value / norm).toList(growable: false);
  }

  void _validateLength(List<double> output) {
    if (output.length != schema.totalFeatures) {
      throw StateError(
        'Frozen feature contract expected ${schema.totalFeatures} values, got ${output.length}.',
      );
    }
  }

  static double _dot(List<double> left, List<double> right) {
    var value = 0.0;
    for (var index = 0; index < left.length; index++) {
      value += left[index] * right[index];
    }
    return value;
  }

  static double _norm(List<double> values) =>
      math.sqrt(values.fold<double>(0, (sum, value) => sum + value * value));
}

class NoteFeatureEvidence {
  const NoteFeatureEvidence({
    required this.noteVector,
    required this.anchorVector,
    required this.specificity,
    required this.gate,
    required this.tokenCount,
    required this.recognisedTokenCount,
    required this.noteAvailable,
  });

  final List<double> noteVector;
  final List<double> anchorVector;
  final double specificity;
  final double gate;
  final int tokenCount;
  final int recognisedTokenCount;
  bool get hasVocabularySignal => recognisedTokenCount > 0;
  final bool noteAvailable;
}
