import 'dart:async';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter_onnxruntime/flutter_onnxruntime.dart';
import 'package:pocketiq/ml/inference/feature_preprocessor.dart';
import 'package:pocketiq/ml/inference/transaction_categoriser.dart';
import 'package:pocketiq/ml/learning/local_calibration_model.dart';

/// Keeps Riverpod wiring synchronous while loading the JSON feature contract
/// and native ONNX session only when the first prediction is requested.
class DeferredOnnxTransactionCategoriser implements TransactionCategoriser {
  DeferredOnnxTransactionCategoriser(
    this.preprocessor, {
    this.calibrationStore,
  });

  final Future<FrozenFeaturePreprocessor> preprocessor;
  final ProbabilityCalibrationStore? calibrationStore;
  Future<OnnxTransactionCategoriser>? _delegate;

  Future<OnnxTransactionCategoriser> _load() => _delegate ??= preprocessor.then(
    (value) => OnnxTransactionCategoriser(
      preprocessor: value,
      calibrationStore: calibrationStore,
    ),
  );

  @override
  Future<CategorisationResult> categorise(
    TransactionInput input, {
    String? smartNote,
  }) async => (await _load()).categorise(input, smartNote: smartNote);

  Future<void> close() async {
    final delegate = await _delegate;
    _delegate = null;
    await delegate?.close();
  }
}

/// Runs the frozen PocketIQ deployment text classifier locally through ONNX.
///
/// Both transaction-text and Smart Note-assisted calls use this same session and
/// model version. The only difference is whether the Smart Note is absent or
/// appended to the same merchant/description/direction text contract.
class OnnxTransactionCategoriser implements TransactionCategoriser {
  OnnxTransactionCategoriser({
    required this.preprocessor,
    this.modelAsset = 'assets/models/model.onnx',
    this.modelVersion = 'pocketiq-deployment-text-v1',
    OnnxRuntime? runtime,
    this.calibrationStore,
  }) : _runtime = runtime ?? OnnxRuntime();

  final FrozenFeaturePreprocessor preprocessor;
  final String modelAsset;
  final String modelVersion;
  final OnnxRuntime _runtime;
  final ProbabilityCalibrationStore? calibrationStore;
  Future<OrtSession>? _session;

  Future<OrtSession> _loadSession() =>
      _session ??= _runtime.createSessionFromAsset(modelAsset);

  @override
  Future<CategorisationResult> categorise(
    TransactionInput input, {
    String? smartNote,
  }) async {
    final note = smartNote?.trim() ?? '';
    final noteEvidence = preprocessor.analyseNote(
      input,
      note,
      eligible: note.isNotEmpty,
    );
    final features = preprocessor.transform(
      input,
      smartNote: note,
      useNote: note.isNotEmpty,
    );
    final tensorContract = preprocessor.schema.tensorContract;
    final inputName = tensorContract['input_name'] as String;
    final outputName = tensorContract['output_name'] as String;
    final session = await _loadSession();
    final inputTensor = await OrtValue.fromList(
      Float32List.fromList(features),
      <int>[1, preprocessor.schema.totalFeatures],
    );
    Map<String, OrtValue>? outputs;
    try {
      outputs = await session.run(<String, OrtValue>{inputName: inputTensor});
      final outputTensor = outputs[outputName];
      if (outputTensor == null) {
        throw StateError(
          'Frozen model did not return the required output "$outputName".',
        );
      }
      final raw = await outputTensor.asFlattenedList();
      final logits = raw.map((value) => (value as num).toDouble()).toList();
      if (logits.length != preprocessor.schema.categories.length) {
        throw StateError(
          'Frozen model returned ${logits.length} logits; '
          'expected ${preprocessor.schema.categories.length}.',
        );
      }
      final rawProbabilities = _softmax(logits);
      final state = await calibrationStore?.load();
      final probabilities = state == null || state.version == 0
          ? rawProbabilities
          : const LocalCalibrationTrainer().calibrate(rawProbabilities, state);
      return resultFromProbabilities(
        input,
        probabilities,
        usedSmartNote: note.isNotEmpty,
        smartNoteHasVocabularySignal: noteEvidence.hasVocabularySignal,
        calibrationVersion: state?.version ?? 0,
      );
    } finally {
      await inputTensor.dispose();
      if (outputs != null) {
        for (final value in outputs.values) {
          await value.dispose();
        }
      }
    }
  }

  CategorisationResult resultFromLogits(
    TransactionInput input,
    List<double> logits, {
    required bool usedSmartNote,
  }) {
    final probabilities = _softmax(logits);
    return resultFromProbabilities(
      input,
      probabilities,
      usedSmartNote: usedSmartNote,
    );
  }

  CategorisationResult resultFromProbabilities(
    TransactionInput input,
    List<double> probabilities, {
    required bool usedSmartNote,
    bool? smartNoteHasVocabularySignal,
    int calibrationVersion = 0,
  }) {
    final ranked = List<int>.generate(probabilities.length, (index) => index)
      ..sort(
        (left, right) => probabilities[right].compareTo(probabilities[left]),
      );
    final top = ranked[0];
    final second = ranked[1];
    final rawCategory = preprocessor.schema.categories[top];
    final rawAlternative = preprocessor.schema.categories[second];
    final entropy = -probabilities.fold<double>(
      0,
      (sum, probability) =>
          sum + (probability <= 0 ? 0 : probability * math.log(probability)),
    );
    final normalizedEntropy = entropy / math.log(probabilities.length);
    return CategorisationResult(
      category: _mobileCategory(
        rawCategory,
        input.transactionType,
        deploymentCategorySpace:
            preprocessor.schema.categorySpace == 'pocketiq',
      ),
      alternative: _mobileCategory(
        rawAlternative,
        input.transactionType,
        deploymentCategorySpace:
            preprocessor.schema.categorySpace == 'pocketiq',
      ),
      researchCategory: rawCategory,
      researchAlternative: rawAlternative,
      confidence: probabilities[top],
      entropy: entropy,
      normalizedEntropyValue: normalizedEntropy,
      margin: probabilities[top] - probabilities[second],
      reasons: <String>[
        if (preprocessor.schema.isDeploymentText)
          'The frozen deployment model evaluated direction, merchant and transaction description text locally'
        else
          'The frozen research model evaluated transaction type, payment mode, location, amount and date features locally',
        if (usedSmartNote && smartNoteHasVocabularySignal == true)
          'The same frozen deployment model re-evaluated the transaction with recognised Smart Note text',
        if (usedSmartNote && smartNoteHasVocabularySignal == false)
          'The Smart Note contained no token represented by the frozen model vocabulary',
        if (calibrationVersion > 0)
          'A locally trained probability calibration layer used your confirmed categories',
        if (!preprocessor.schema.isDeploymentText)
          'This legacy research checkpoint does not use merchant or free-text transaction descriptions',
        'No transaction text or Smart Note was sent to a server',
      ],
      isDemo: false,
      probabilities: List<double>.unmodifiable(probabilities),
      modelVersion: calibrationVersion == 0
          ? modelVersion
          : '$modelVersion+calibration-v$calibrationVersion',
    );
  }

  Future<void> close() async {
    final session = await _session;
    _session = null;
    await session?.close();
  }

  static List<double> _softmax(List<double> logits) {
    final maximum = logits.reduce(math.max);
    final exponentials = logits
        .map((value) => math.exp(value - maximum))
        .toList(growable: false);
    final denominator = exponentials.fold<double>(
      0,
      (sum, value) => sum + value,
    );
    return exponentials
        .map((value) => value / denominator)
        .toList(growable: false);
  }

  static String _mobileCategory(
    String modelCategory,
    String transactionType, {
    required bool deploymentCategorySpace,
  }) {
    final isIncome = transactionType.toLowerCase() == 'income';
    if (deploymentCategorySpace) {
      if (isIncome) {
        return switch (modelCategory) {
          'Other Income' => 'Other Income',
          'Transfers' => 'Account Transfer',
          _ => 'Other Income',
        };
      }
      return modelCategory == 'Other Income' ? 'Other Spending' : modelCategory;
    }
    if (isIncome) {
      return switch (modelCategory) {
        'Bonus' => 'Bonus & Commission',
        'Freelance' => 'Business & Freelance Income',
        'Investment' => 'Investment Income',
        'Rent' => 'Rental Income',
        'Salary' => 'Salary',
        'Savings' => 'Account Transfer',
        'Other' => 'Other Income',
        // These research labels describe spending. Reinterpreting them as an
        // income category would be misleading, so use the explicit fallback.
        _ => 'Other Income',
      };
    }
    return switch (modelCategory) {
      'Bonus' => 'Other Spending',
      'Education' => 'Education',
      'Entertainment' => 'Entertainment',
      'Food' => 'Food & Dining',
      'Freelance' => 'Business Expenses',
      'Health' => 'Health & Medical',
      'Investment' => 'Other Spending',
      'Other' => 'Other Spending',
      'Rent' => 'Housing',
      'Salary' => 'Other Spending',
      'Savings' => 'Transfers',
      'Travel' => 'Travel',
      'Utilities' => 'Bills & Utilities',
      _ => 'Other Spending',
    };
  }
}
