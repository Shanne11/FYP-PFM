import 'package:drift/native.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:pocketiq/core/database/app_database.dart';
import 'package:pocketiq/ml/learning/local_calibration_model.dart';
import 'package:pocketiq/ml/learning/optional_learning_service.dart';

void main() {
  test('remote optional-learning upload is disabled', () {
    expect(OptionalLearningService.remoteSyncEnabled, isFalse);
  });

  test('syncPending rejects direct programmatic calls', () async {
    final database = AppDatabase(NativeDatabase.memory());
    addTearDown(database.close);
    final service = OptionalLearningService(
      database,
      ProbabilityCalibrationStore(),
    );

    await expectLater(
      service.syncPending(
        'https://example.invalid/calibration',
        researchToken: 'unused-test-token',
      ),
      throwsA(
        isA<StateError>().having(
          (error) => error.message,
          'message',
          contains('upload is disabled'),
        ),
      ),
    );
  });
}
